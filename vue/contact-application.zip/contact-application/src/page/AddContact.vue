<template>
  <div class="parent-container">
    <input
      type="text"
      placeholder="Enter Name"
      v-model="contactDetails.name"
    /><br />
    <input
      type="text"
      placeholder="Contact Number"
      v-model="contactDetails.contactNo"
    /><br />
    <input
      type="text"
      placeholder="Email Id"
      v-model="contactDetails.emailId"
    /><br />
    <button @click="addContact()">+SAVE</button>
  </div>
</template>
<script>
export default {
  name: "AddContact",
  data() {
    return {
      contactDetails: {
        id: Date.now().toString(36),
        name: null,
        contactNo: null,
        emailId: null,
        isFavorite: false,
        profileName: null,
        callLogs: [],
      },
      addContactDetails: [],
    };
  },
  created() {
    this.addContactDetails =
      JSON.parse(localStorage.getItem("contactDetails")) || [];
  },
  methods: {
    addContact() {
      this.contactDetails.profileName = this.contactDetails.name.charAt(0);
      this.addContactDetails.push(this.contactDetails);
      localStorage.setItem(
        "contactDetails",
        JSON.stringify(this.addContactDetails)
      );
    },
  },
};
</script>
<style scoped>
input {
  width: 40%;
  height: 20px;
  margin: 10px;
  padding: 10px;
}
button {
  margin: 10px;
  background-color: white;
  color: black;
  border: 2px solid green;
  padding: 10px 20px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
}

button:hover {
  background-color: green;
  color: white;
}
</style>
