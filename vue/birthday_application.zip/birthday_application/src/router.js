import { createRouter, createWebHistory } from "vue-router";

import allBirthdayList from "@/pages/allBirthdayList";
import todayBirthdayList from "@/pages/todayBirthdayList";
import upComingBirthdayList from "@/pages/upComingBirthdayList";
import closeFriendBirthdayList from "@/pages/closeFriendBirthdayList";
import birthdayWish from "@/pages/birthdayWish";
import pageNotFound from "@/pages/pageNotFound";

const router = createRouter({
  history: createWebHistory(),
  routes: [
    { name: "allBirthday", path: "/allBirthday", component: allBirthdayList },
    { path: "/", redirect: "/allBirthday" },
    {
      name: "todayBirthday",
      path: "/todayBirthday",
      component: todayBirthdayList,
    },
    {
      name: "upComingBirthday",
      path: "/upComingBirthday",
      component: upComingBirthdayList,
    },
    {
      name: "closeFriendBirthday",
      path: "/closeFriendBirthday",
      component: closeFriendBirthdayList,
    },
    {
      name: "birthdayWish",
      path: "/birthdayWish/:userId",
      component: birthdayWish,
      props: true,
      beforeEnter: (to, from, next) => {
        const userData = JSON.parse(localStorage.getItem("userDataList")) || [];
        const isUserExist = userData.find(
          (user) => user.id === +to.params.userId
        );
        if (!isUserExist) {
          return router.back();
        }
        const date = new Date();
        let currentDate = `${String(date.getMonth() + 1).padStart(
          2,
          "0"
        )}-${String(date.getDate()).padStart(2, "0")}`;

        return isUserExist.dob.slice(5) === currentDate
          ? next()
          : router.back();
      },
    },
    {
      name: "pageNotFound",
      path: "/:pageNotFound(.*)",
      component: pageNotFound,
    },
  ],
});

export default router;
