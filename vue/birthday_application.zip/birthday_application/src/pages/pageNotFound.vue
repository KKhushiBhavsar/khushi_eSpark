<template>
  <h2>Page Not Found</h2>
</template>

<script>
export default {
  name: "pageNotFound",
};
</script>

<style scoped>
h2 {
  font-size: 2rem;
  font-weight: 600;
  color: #8f8e8e;
}
</style>
